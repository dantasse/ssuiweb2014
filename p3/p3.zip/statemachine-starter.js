// Your task is to fill in the rest of this file with your state machine, and then save
// the file to statemachine.js.
function StateMachine(description, elementToAttach) {
}
