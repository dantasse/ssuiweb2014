// JavaScript Document
console.log("hello node");